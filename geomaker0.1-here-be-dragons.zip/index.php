<?php include('controller.php');?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
  <title>GeoMaker - Convert web sites and texts into Maps and Geo Microformats</title>
  <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/combo?2.7.0/build/reset-fonts-grids/reset-fonts-grids.css&2.7.0/build/base/base-min.css">
  <link rel="stylesheet" type="text/css" href="geomaker.css">
  <script type="text/javascript" src="http://yui.yahooapis.com/2.7.0/build/yuiloader/yuiloader-min.js"></script> 
</head>
<body class="yui-skin-sam">
<div id="doc" class="yui-t7">
  <div id="hd" role="banner">
    <h1>GeoMaker</h1>
    <p id="update">Londoners: free tech talk about how this was done <a href="http://upcoming.yahoo.com/event/2799061/">next Tuesday at SkillsMatter!</a></p>
  </div>
  <div id="bd" role="main">
    
    <div class="yui-gb" id="tabs">
      <div class="yui-u first
      <?php if(!isset($out) && !isset($final)){ echo 'current';}?>
      "><h2><span>1 </span>Input</h2><p>Enter or load content</p></div>
      <div class="yui-u
      <?php echo isset($out) ? ' current' : ''; ?>
      "><h2><span>2 </span> Filter</h2><p>Pick geo locations</p></div>
      <div class="yui-u
      <?php echo isset($final) ? ' current' : ''; ?>
      "><h2><span>3 </span> Output</h2><p>Get map and microformats code</p></div>
    </div>
    
    <form action="index.php" method="post">
 
        <?php if(!isset($_POST['stage'])){?>
        <div class="intro">GeoMaker creates microformats and maps from geographical information embedded in texts. You can either provide a URL to load and hit the "load content" button or start typing your own text and hit the "get locations" button to continue.</div>  
          
        <h2>Get content from web:</h2>
        <div id="load"><label for="url">Load content from:</label>
        <?php if($cleancontent!=''){?><?php }?>
        <input type="text" name="url" id="url" value="<?php echo $url;?>">
        <input type="submit" id="loadcontent" value="load content" name="loadcontent">
        </div><input type="hidden" name="stage" value="check">

        <h2>or enter some text to analyze:</h2>
        <label for="message">Text content</label>
        <textarea name="message" id="message"><?php 
        if($cleancontent != ''){
          echo $cleancontent;
        } else {
        echo urldecode($message);}?></textarea>
        <div class="submit"><input type="submit" id="analyze" value="get locations" name="analyze"></div>
        <?php } ?>

        <?php if($_POST['stage']=='check'){?>
        <div class="intro">Cleanup time. As not all things machines find for us are really what we were looking for check the table below and uncheck results you don't want to have on your map. Possible duplicates have already been unchecked. Once you're done, hit the generate button to continue.</div>  
        <h2>Results</h2>
        <?php echo $out;?>
        <?php }?>

        <?php if($_POST['stage']=='display'){ ?>
        <div class="intro">And we're done. Below you'll see the map with your locations, the code to copy and paste to embed your own map and your locations as microformats.</div>  
<?php include('mapcode.php');?>
<div class="yui-g">
  <div class="yui-u first">
    <h3>Your Map code</h3>
    <p>Following is the code to generate the map above. For you to use it in your own products you need to <a href="https://developer.yahoo.com/wsregapp/">apply for a free map developer key</a> and replace the <code>YMAPPID</code> in the code with your own key.</p>
    <textarea><?php include('mapcode.php');?></textarea>
  </div>
  <div class="yui-u">
    <h3>Your Microformatted locations</h3>
    <p>If all you wanted is geolocate your text, here are the geo-microformats to copy and paste into the correct sections. Notice that we are not using the <code>ABBR</code> pattern as accessibility is something we care about.</p>
    <textarea><?php echo join("\n",$mf);?></textarea>
  </div>
</div>

<div class="submit"><input type="submit" value="Start over" id="restart" name="restart"></div>
<?php }?>
    
    </form>
  </div>
  <div id="ft" role="contentinfo"><p>GeoMaker by <a href="http://wait-till-i.com">Christian Heilmann</a>, using <a href="http://developer.yahoo.com/yui">YUI</a>, <a href="http://developer.yahoo.com/yql">YQL</a> and <a href="http://developer.yahoo.com/geo">Yahoo Geo Technologies</a> - <a href="api.php"><strong>GeoMaker for Developers</strong></a></p></div>
</div>
<script type="text/javascript" charset="utf-8" src="geomaker.js"></script>
<!-- Start of StatCounter Code -->
<script type="text/javascript">
var sc_project=968400; 
var sc_invisible=1; 
var sc_partition=46; 
var sc_click_stat=1; 
var sc_security="55a9fb8f"; 
var sc_text=2; 
</script>

<script type="text/javascript"
src="http://www.statcounter.com/counter/counter.js"></script><noscript><div
class="statcounter"><a title="iweb stats"
href="http://www.statcounter.com/iweb/" target="_blank"><img
class="statcounter"
src="http://c.statcounter.com/968400/0/55a9fb8f/1/"
alt="iweb stats" ></a></div></noscript>
<!-- End of StatCounter Code -->
</body>
</html>
