<?php
include('apifunctions.php');
if(isset($_GET['url'])){
  $_POST['stage']='check';
  $_POST['url'] = $_GET['url'];
  $_POST['loadcontent']='meh';
}

$key = '4HjHmAfV34EriHQuqW_7P6A5_eFww96Yic4a7dlDtkoT_3LHNNkrAHskOnoZK9A-';
if($_POST['stage']=='check'){
  if(isset($_POST['loadcontent'])){
    $url = filter_input(INPUT_POST, 'url', FILTER_SANITIZE_URL);
    $url = $_POST['url'];
    $c = grab($url);
    if(strstr($c,'<')){
       $c = preg_replace("/.*<results>|<\/results>.*/",'',$c);
       $c = preg_replace("/<\?xml version=\"1\.0\"".
                         " encoding=\"UTF-8\"\?>/",'',$c);
      $cleancontent = preg_replace("/<script[^>]+>.*<\/script>/msi"," ",$cleancontent);
       $cleancontent = strip_tags($c);
       $cleancontent = preg_replace("/[\r?\n]+/"," ",$cleancontent);
       $_POST['message'] = $cleancontent;
     }
  }
  $x = postToPlacemaker($cleancontent);     
   $places = simplexml_load_string($x, 'SimpleXMLElement', LIBXML_NOCDATA);    
   $out = '';
     if($places->document->placeDetails){
   $foundplaces = makewoeidhash($places);
   $out.='<div id="sorter"><table id="foundresults">';
   $out.= '<caption>Found Locations </caption>';
   $out.= '<thead>';
   $out.= '<th scope="row">Use</th>';
   $out.= '<th scope="row">Match</th>';
   $out.= '<th scope="row">Real Name</th>';
   $out.= '<th scope="row">Type</th>'; 
   $out.= '<th scope="row">woeid</th>'; 
   $out.= '<th scope="row">Latitude</th>';
   $out.= '<th scope="row">Longitude</th>';
   $out.= '</thead>';
   $out.= '<tbody>';
   $refs = $places->document->referenceList->reference;
     $count =0;
     foreach($refs as $r){
       foreach($r->woeIds as $wi){
         $currentloc = $foundplaces["woeid".$wi];
         if($r->text!='' && $currentloc['name']!='' && 
            $currentloc['lat']!='' && $currentloc['lon']!=''){
            $count++;
            $out.= ($count %2==0) ? '<tr class="odd">' : '<tr>';
            $text = preg_replace('/\n/','',$r->text);
            $current = $wi.'|'.$currentloc['name'].'|'.$text.'|'.
                       $currentloc['lat'].'|'.$currentloc['lon'];
            $out.= '<td><input type="checkbox" ';
            if($wi.''!=$wo.''){
              $out.= 'checked="checked"';
            }
            $out.=' name="collection[]" value="'.$current.'"></td>';
            $out.= '<td>'.$r->text.'</td>';
            $out.= '<td>'.str_replace(', ZZ','',$currentloc['name']).'</td>';
            $out.= '<td>'.$currentloc['type'].'</td>';
            $out.= '<td>'.$wi.'</td>';
            $out.= '<td>'.$currentloc['lat'].'</td>';
            $out.= '<td>'.$currentloc['lon'].'</td>';
            $out.= '</tr>';
          }
       }
      $wo = $r->woeIds;
    }
     $out.= '</tbody></table></div><input type="hidden" name="stage" value="display"><div class="submit"><input type="submit" value="generate" id="final" name="final"></div>';
   } else {
     $out.= '<h2>Couldn\'t find any locations :-( </h2><div  class="submit"><input type="submit" value="Start over" id="restart" name="restart"></div>
     ';
   }
 } 
 if($_POST['stage']=='display'){
    $final = filter_input(INPUT_POST, 'final', FILTER_SANITIZE_ENCODED);
    $points = preg_replace('/\n|\r/msi','','['.join(',',$_POST['collection']).']');
    $points = array();
    $mfs = array();
    foreach($_POST['collection'] as $c){
      $chunks = explode('|',$c);
                
      $mf[]="\n\n<-- match:".$chunks[2]." -->\n".
                "<span class=\"vcard\">\n<span class=\"adr\">\n".
                "<span class=\"locality\">$chunks[1]</span>\n".
                "</span>\n(<span class=\"geo\">\n".
                "<span class=\"latitude\">$chunks[3]</span>,\n".
                "<span class=\"longitude\">$chunks[4]</span>".
                "\n</span>)\n</span>";
      $points[]='{"lat":"'.$chunks[3].'","lon":"'.$chunks[4].'","title":"'.$chunks[1].'"}';
    }
    $points = '['.join(',',$points).']';
 }


?>