

function bla(){


}
var baa = 'sheep';