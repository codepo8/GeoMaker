<?php
function makewoeidhash($places){
  $foundplaces = array();
  foreach($places->document->placeDetails as $p){
    $wkey = 'woeid'.$p->place->woeId;
    $foundplaces[$wkey]=array(
      'name'=>$p->place->name.'',
      'type'=>$p->place->type.'',
      'woeId'=>$p->place->woeId.'',
      'lat'=>$p->place->centroid->latitude.'',
      'lon'=>$p->place->centroid->longitude.''
    );
  }
  return $foundplaces;
}
function postToPlacemaker($content){
  global $key;
  $ch = curl_init(); 
  if(isset($_GET['lang'])){
    $lang = '&inputLanguage='.$_GET['lang'];
  }
  define('POSTURL', 'http://wherein.yahooapis.com/v1/document');
  define('POSTVARS', 'appid='.$key.'&documentContent='.urlencode($content).
                  '&documentType=text/html&outputType=xml'.$lang);
  
  $ch = curl_init(POSTURL);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, POSTVARS);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  

  $x = curl_exec($ch);
  return $x;
}

function grab($url){
  $realurl ='http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20html%20where%20url%20%3D%20%22'.urlencode($url).'%22&format=xml';
  $ch = curl_init(); 
  curl_setopt($ch, CURLOPT_URL, $realurl); 
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
  $c = curl_exec($ch); 
  curl_close($ch);
  return $c;
}
?>